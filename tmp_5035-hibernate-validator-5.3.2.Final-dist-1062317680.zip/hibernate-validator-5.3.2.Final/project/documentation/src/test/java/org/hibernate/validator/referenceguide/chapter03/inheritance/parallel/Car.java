package org.hibernate.validator.referenceguide.chapter03.inheritance.parallel;

public interface Car {

	void drive(int speedInMph);
}
